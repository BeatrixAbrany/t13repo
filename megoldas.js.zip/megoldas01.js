<script>
//1. feladat
document.write("1. feladat <br/>");
let nev=prompt(("Add meg a neved"));
let azon=Number(prompt("Add meg a csoportod azonosítóját"));
let ht= Number(prompt("Mennyire érted a HTML tananyagokat 1-100-ig"));
let cs=Number(prompt("Mennyire érted a CSS tananyagokat 1-100-ig"));
let js=Number(prompt("Mennyire érted a JS tananyagokat 1-100-ig"));

document.write("Név: "+nev+"<br/>");
document.write("#Team: "+azon+"<br/>");
document.write("HTML: "+ht+"<br/>");
document.write("CSS: "+cs+"<br/>");
document.write("JS: "+js+"<br/>");


</script>

