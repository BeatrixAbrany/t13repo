<script>
//6. feladat
document.write("6. feladat <br/>");

for(let i=1; i<=10; i++)
{
let er=i*i;
document.write(er+" ")
}
</script>

